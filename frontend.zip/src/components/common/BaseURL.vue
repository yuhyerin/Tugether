<template>
    <div></div>
</template>

<script>
export default {

}
// 로컬 작업 시
export let base = 'http://localhost:8080';
// 서버 배포 시
// export const base = 'https://i3b303.p.ssafy.io';
</script>