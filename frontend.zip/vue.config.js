
module.exports = {
  
  configureWebpack:{
    
    performance: {
      hints: false
    },
  },
  

  "transpileDependencies": [
    "vuetify"
  ]
}